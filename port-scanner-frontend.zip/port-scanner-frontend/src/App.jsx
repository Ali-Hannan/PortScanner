import { useState } from 'react';
import './App.css'; 

function App() {
  const [host, setHost] = useState('');
  const [ports, setPorts] = useState('');
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleScan = async (e) => {
    e.preventDefault();

    if (!host || !ports) {
      setError('Please enter a host and at least one port.');
      return;
    }

    const portArray = ports.split(',').map(p => parseInt(p.trim()));

    try {
      setLoading(true);
      setError('');
      const response = await fetch('http://127.0.0.1:5000/scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ host, ports: portArray })
      });

      const data = await response.json();
      setResults(data);
    } catch (err) {
      setError('Error connecting to backend.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container">
      <h1>Port Scanner Tool</h1>
      <form className="form" onSubmit={handleScan}>
        <input
          type="text"
          placeholder="Enter host (e.g. scanme.nmap.org)"
          value={host}
          onChange={(e) => setHost(e.target.value)}
        />
        <input
          type="text"
          placeholder="Enter ports (e.g. 22, 80, 443)"
          value={ports}
          onChange={(e) => setPorts(e.target.value)}
        />
        <button type="submit">
          {loading ? 'Scanning...' : 'Scan Ports'}
        </button>
      </form>
      {loading && <div className="spinner"></div>}


      {error && <div className="error">{error}</div>}

      {results.length > 0 && (
        <div className="results">
          <h2>Scan Results</h2>
          <ul>
            {results.map((res, index) => (
              <li
                key={index}
                className={res.status === 'open' ? 'open' : 'closed'}
                title={res.status === 'open' ? 'This port is open and accepting connections' : 'This port is closed or blocked'}
              >
                <strong>
                  {res.status === 'open' ? '🔓' : '🔒'} Port {res.port}
                </strong> — {res.status.toUpperCase()} ({res.service})
                {res.status === 'open' && <p className="fact">💡 {res.fun_fact}</p>}
              </li>

            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

export default App;
